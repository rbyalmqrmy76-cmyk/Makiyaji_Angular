import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'currencyYer',
  standalone: true
})
export class CurrencyYerPipe implements PipeTransform {
  transform(value: number | string): string {
    if (!value) return '0 ر.ي';
    const formatter = new Intl.NumberFormat('ar-YE', {
      style: 'decimal',
      minimumFractionDigits: 0
    });
    return `${formatter.format(Number(value))} ر.ي`;
  }
}
