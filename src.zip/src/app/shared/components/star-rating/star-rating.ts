import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-star-rating',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="star-rating">
      <span *ngFor="let star of [1, 2, 3, 4, 5]" 
            class="star" 
            [class.filled]="star <= rating()">
        ★
      </span>
      <span class="rating-value" *ngIf="showValue()">({{ rating() }})</span>
    </div>
  `,
  styles: [`
    .star-rating {
      display: inline-flex;
      align-items: center;
      gap: 2px;
      direction: ltr; /* Stars read better ltr for fill-level usually, but we keep it simple */
    }
    .star {
      color: #e5e7eb;
      font-size: 1.1rem;
    }
    .star.filled {
      color: #fbbf24;
    }
    .rating-value {
      margin-left: 8px;
      font-size: 0.85rem;
      color: var(--text-muted);
    }
  `]
})
export class StarRating {
  rating = input<number>(0);
  showValue = input<boolean>(true);
}
